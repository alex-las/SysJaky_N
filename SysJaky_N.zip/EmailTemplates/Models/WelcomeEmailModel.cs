namespace SysJaky_N.EmailTemplates.Models;

public record class WelcomeEmailModel(string Email, string? Name);
