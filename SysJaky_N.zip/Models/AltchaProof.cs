﻿namespace SysJaky_N.Models;

public sealed class AltchaProof
{
    public string Algorithm { get; set; } = "SHA-256";

    public int Difficulty { get; set; }
    public string Challenge { get; set; } = string.Empty; // = seed
    public long Number { get; set; }                 // výsledek z workeru
    public string Salt { get; set; } = string.Empty; // např. s expirací v query
    public string Signature { get; set; } = string.Empty; // HMAC serveru
    public bool? Test { get; set; }                 // volitelné
    public long? Took { get; set; }                 // volitelné
}