namespace SysJaky_N.EmailTemplates.Models;

public record NewsletterConfirmationEmailModel(string Email, string ConfirmationUrl);
