global using SysJaky_N.Authorization;
