# PWA Icon Placeholders

Tato složka je určena pro produkční ikony PWA aplikace (`icon-192.png`, `icon-256.png`, `icon-512.png`, `icon-maskable-512.png`).

Pro lokální vývoj si sem nahrajte odpovídající PNG soubory. V produkci by tyto soubory měly být poskytovány buď build pipeline, nebo CDN.
