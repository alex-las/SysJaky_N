namespace SysJaky_N.Models;

public class CartItem
{
    public int CourseId { get; set; }
    public int Quantity { get; set; }
}
