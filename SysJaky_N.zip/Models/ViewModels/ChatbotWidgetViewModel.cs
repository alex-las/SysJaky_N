namespace SysJaky_N.Models.ViewModels;

public class ChatbotWidgetViewModel
{
    public bool AutoInitialize { get; set; }
}
