﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SysJaky_N.Services;
using SysJaky_N.Models;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Text;

namespace SysJaky_N.Controllers;

[ApiController]
[Route("altcha")]
public class AltchaController : ControllerBase
{
    private readonly IAltchaService _altchaService;
    private readonly ILogger<AltchaController> _logger;

    public AltchaController(IAltchaService altchaService, ILogger<AltchaController> logger)
    {
        _altchaService = altchaService;
        _logger = logger;
    }

    [HttpGet("challenge")]
    public ActionResult<AltchaChallenge> GetChallenge()
    {
        var correlationId = HttpContext.TraceIdentifier;
        _logger.LogInformation("ChallengeIssued {CorrelationId}", correlationId);
        return _altchaService.CreateChallenge();
    }

    [HttpPost("verify")]
    [Consumes("application/json")]
    [EnableRateLimiting("AltchaVerify")]
    [IgnoreAntiforgeryToken]
    public ActionResult<object> Verify([FromBody] AltchaVerifyRequest request)
    {
        _logger.LogInformation("VerifyAttempted {CorrelationId}", HttpContext.TraceIdentifier);

        if (string.IsNullOrWhiteSpace(request.Payload))
            return BadRequest(new { success = false, error = "Missing payload" });

        // 1) Rozbal base64 → JSON → AltchaProof
        AltchaProof? proof;
        try
        {
            var raw = Convert.FromBase64String(request.Payload);
            var json = Encoding.UTF8.GetString(raw);
            proof = JsonSerializer.Deserialize<AltchaProof>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Invalid payload");
            return Ok(new { success = false, ok = false, valid = false });
        }

        if (proof is null)
            return Ok(new { success = false, ok = false, valid = false });

        // 2) Ověření přes službu
        var success = _altchaService.Verify(proof);

        if (!success)
        {
            _logger.LogWarning("VerifyFailed {CorrelationId}", HttpContext.TraceIdentifier);
            return Ok(new { success = false, ok = false, valid = false });
        }

        _logger.LogInformation("VerifySucceeded {CorrelationId}", HttpContext.TraceIdentifier);

        // 3) Pro kompatibilitu vrať zpět i 'payload' (Altcha si ho uloží do hidden inputu)
        return Ok(new { success = true, ok = true, valid = true, payload = request.Payload });
    }

}
