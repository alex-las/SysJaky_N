namespace SysJaky_N;

public class SharedResource { }
