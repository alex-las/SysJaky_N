namespace SysJaky_N.EmailTemplates.Models;

public record class CourseReviewRequestEmailModel(string CourseTitle, string ReviewUrl);
