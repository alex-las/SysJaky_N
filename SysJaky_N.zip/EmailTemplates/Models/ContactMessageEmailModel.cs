namespace SysJaky_N.EmailTemplates.Models;

public record class ContactMessageEmailModel(string SenderName, string SenderEmail, string Message);
